//David Durkin
//Fund Comp II
//Puzzle.cpp

#include "Puzzle.h"
#include <iostream>

//empty .cpp file, implementation is in the .h file as it is a templated class