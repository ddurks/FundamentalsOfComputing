//David Durkin
//Fund Comp II
//Main function for Language Finder

#include "Language.h"
#include <iostream>

int main(){

	Language test;
	test.findLang();
	return 0;

}